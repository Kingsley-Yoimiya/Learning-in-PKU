let h1 = document.createElement("h1");

h1.textContent = "Web世界，你好！";

document.body.appendChild(h1);

let p = document.createElement("p");

p.textContent = "我养了两只猫。一只叫哈瑞，一只叫罗恩。";

document.body.appendChild(p);

