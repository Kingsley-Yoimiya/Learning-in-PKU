#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include <sys/wait.h>
#include <pthread.h>

#include "util.h"
#include "ringbuffer.h"

#define DATA_SIZE 617

static int message_count;
static size_t message_size;

typedef struct {
	uint64_t number;
    uint8_t  finish;
	char dummy[DATA_SIZE];
} DummyType;

int main (int argc, char *argv []) {

    int i;
    unsigned long elapsed;
    unsigned long throughput;
    double megabits;
    void* watch;


    if (argc != 2) {
        printf ("usage: %s <message-count>\n", argv[0]);
        return 1;
    }

    message_size = DATA_SIZE;
    message_count = atoi (argv[1]);

    const char *queue_name = "test";
    ringbuffer_t* rb = create_ringbuffer_shm(queue_name, sizeof(DummyType));

    printf ("message size: %d [B]\n", (int) message_size);
    printf ("message count: %d\n", (int) message_count);

    watch = stopwatch_start();
	DummyType lastInsert;
	lastInsert.finish = 0;
    for (i = 0; i != message_count; i++) {
		lastInsert.number = i+1;
		while (write_ringbuffer(rb, &lastInsert, sizeof(DummyType)) < 0) {}
        // flush_ringbuffer(rb);
    }
	lastInsert.number = 0;
	lastInsert.finish = 1;
	while (write_ringbuffer(rb, &lastInsert, sizeof(DummyType)) < 0) {}
    // flush_ringbuffer(rb);

    elapsed = stopwatch_stop(watch);
    if (elapsed == 0)
        elapsed = 1;

    throughput = (unsigned long)
        ((double) message_count / (double) elapsed * 1000000);
    megabits = ((double) (throughput) / 1000000) * message_size;

    printf ("mean throughput: %d [msg/s]\n", (int) throughput);
    printf ("mean throughput: %.3f [MB/s]\n", (double) megabits);

    close_ringbuffer_shm(rb);
    return 0;
}


