#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include <sys/wait.h>
#include <pthread.h>

#include "util.h"
#include "ringbuffer.h"

#define DATA_SIZE 617

typedef struct {
	uint64_t number;
    uint8_t  finish;
	char dummy[DATA_SIZE];
} DummyType;

int main (int argc, char *argv [])
{
    const char *queue_name = "test";
    //Queue queue(queue_name, false);
    ringbuffer_t* rb = connect_ringbuffer_shm(queue_name, sizeof(DummyType));
    if (rb == NULL) {
        printf("error: cannot connect to %s\n", queue_name);
        exit(1);
    } else {
        printf("Successfully connect to %s\n", queue_name);
    }

    uint64_t count = 0;
    DummyType lastReceived;
    while (1) {
        while (read_ringbuffer(rb, &lastReceived) < 0) {}
        if (lastReceived.finish) {
            if (count == 0) continue;
            else break;
        }
        count++;
        printf ("Received a message!\n");
        if (lastReceived.number != count) {
            printf ("error: %luth msg with incorrect number %lu\n", count, lastReceived.number);
            return 0;
        }
    }

    printf ("message count: %lu\n", count);

    close_ringbuffer_shm(rb);

    return 0;
}

