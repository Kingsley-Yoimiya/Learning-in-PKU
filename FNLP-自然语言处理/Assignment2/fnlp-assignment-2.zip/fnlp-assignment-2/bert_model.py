import json
import torch
from transformers import BertTokenizer, BertForSequenceClassification
from transformers import Trainer, TrainingArguments
from torch.utils.data import Dataset
from sklearn.metrics import accuracy_score, f1_score
import numpy as np
from fnlp_data_loader import load_20newsgroups, load_hoc

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

class TextDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_length=128):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = str(self.texts[idx])
        label = self.labels[idx]
        
        encoding = self.tokenizer(
            text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'labels': torch.tensor(label, dtype=torch.long)
        }

def compute_metrics(pred):
    labels = pred.label_ids
    preds = pred.predictions.argmax(-1)
    
    return {
        'accuracy': accuracy_score(labels, preds),
        'macro_f1': f1_score(labels, preds, average='macro'),
        'micro_f1': f1_score(labels, preds, average='micro')
    }

def train_bert(train_dataset, test_dataset, num_labels):
    model_name = "google-bert/bert-base-uncased"
    model = BertForSequenceClassification.from_pretrained(
        model_name,
        num_labels=num_labels
    ).to(device)
    training_args = TrainingArguments(
        output_dir='./results',
        num_train_epochs=10,
        per_device_train_batch_size=16,
        per_device_eval_batch_size=16,
        learning_rate=3e-5,
        warmup_ratio=0.1,
        weight_decay=0.01,
        eval_strategy="epoch",
        logging_steps=50,
    )
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=test_dataset,
        compute_metrics=compute_metrics
    )
    trainer.train()
    train_metrics = trainer.evaluate(eval_dataset=train_dataset)
    test_metrics = trainer.evaluate(eval_dataset=test_dataset)
    return {
        'train': {
            'accuracy': train_metrics['eval_accuracy'],
            'macro_f1': train_metrics['eval_macro_f1'],
            'micro_f1': train_metrics['eval_micro_f1']
        },
        'test': {
            'accuracy': test_metrics['eval_accuracy'],
            'macro_f1': test_metrics['eval_macro_f1'],
            'micro_f1': test_metrics['eval_micro_f1']
        }
    }

def bert_model():
    results = {}
    
    tokenizer = BertTokenizer.from_pretrained("google-bert/bert-base-uncased")
    print("[processing] 20-Newsgroups ...")
    newsgroups = load_20newsgroups()
    
    train_dataset = TextDataset(
        newsgroups['train']['text'],
        newsgroups['train']['label'],
        tokenizer
    )
    test_dataset = TextDataset(
        newsgroups['test']['text'],
        newsgroups['test']['label'],
        tokenizer
    )
    
    newsgroups_metrics = train_bert(
        train_dataset,
        test_dataset,
        num_labels=20
    )
    results['20newsgroups'] = newsgroups_metrics
    
    print("[processing] HOC ...")
    hoc = load_hoc()
    
    hoc_train_dataset = TextDataset(
        hoc['train']['text'],
        hoc['train']['label'],
        tokenizer
    )
    hoc_test_dataset = TextDataset(
        hoc['test']['text'],
        hoc['test']['label'],
        tokenizer
    )
    
    hoc_metrics = train_bert(
        hoc_train_dataset,
        hoc_test_dataset,
        num_labels=11
    )
    results['HoC'] = hoc_metrics
    
    print("\nfinish BERT training!")
    return results

if __name__ == '__main__':
    results = bert_model()
    with open('bert_results.json', 'w') as f:
        json.dump(results, f, indent=4)