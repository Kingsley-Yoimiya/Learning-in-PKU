import json
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, f1_score
from fnlp_data_loader import load_20newsgroups, load_hoc

def train(X_train, y_train, X_test, y_test):
    vectorizer = TfidfVectorizer(
        ngram_range=(1, 2),
        max_features=50000,
        sublinear_tf=True
    )
    model = Pipeline([
        ('tfidf', vectorizer),
        ('clf', LogisticRegression(
            max_iter=1000,
            solver='saga',
            multi_class='multinomial',
            n_jobs=-1,
            random_state=29
        ))
    ])
    model.fit(X_train, y_train)
    
    train_pred = model.predict(X_train)
    test_pred = model.predict(X_test)
    
    metrics = {
        'train': {
            'accuracy': accuracy_score(y_train, train_pred),
            'macro_f1': f1_score(y_train, train_pred, average='macro'),
            'micro_f1': f1_score(y_train, train_pred, average='micro')
        },
        'test': {
            'accuracy': accuracy_score(y_test, test_pred),
            'macro_f1': f1_score(y_test, test_pred, average='macro'),
            'micro_f1': f1_score(y_test, test_pred, average='micro')
        }
    }
    
    return metrics

def log_linear_model():
    results = {}
    print("[processing] 20-Newsgroups ...")
    newsgroups = load_20newsgroups()
    train_text = newsgroups['train']['text']
    train_labels = newsgroups['train']['label']
    test_text = newsgroups['test']['text']
    test_labels = newsgroups['test']['label']
    
    newsgroups_metrics = train(train_text, train_labels, test_text, test_labels)
    results['20newsgroups'] = newsgroups_metrics
    
    print("[procerssing] HOC ...")
    hoc = load_hoc()
    hoc_metrics = train(
        hoc['train']['text'], hoc['train']['label'],
        hoc['test']['text'], hoc['test']['label']
    )
    results['HoC'] = hoc_metrics
    print("\nfinish log-linear training!")
    return results

if __name__ == '__main__':
    results = log_linear_model()
    with open('results.json', 'w') as f:
        json.dump(results, f, indent=4)