from log_linear import log_linear_model
from bert_model import bert_model
import json

def whole_model():
    return {
        "loglinear": log_linear_model(),
        "bert": bert_model()
    }

if __name__ == '__main__':
    results = whole_model()
    with open('results.json', 'w') as f:
        json.dump(results, f, indent=4)