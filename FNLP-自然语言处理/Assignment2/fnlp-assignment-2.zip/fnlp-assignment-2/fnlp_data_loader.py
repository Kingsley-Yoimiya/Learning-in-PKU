
import pandas as pd
import os
from datasets import load_dataset

def load_20newsgroups():
    print("""[loading] 20-Newsgroups ...""")
    dataset = load_dataset('SetFit/20_newsgroups')
    return dataset

def load_hoc():
    print("""[loading] HOC ... """)
    train_path = './data/HoC/train.parquet'
    test_path = './data/HoC/test.parquet'
    train_df = pd.read_parquet(train_path)
    test_df = pd.read_parquet(test_path)
    
    return {
        'train': {'text': train_df['text'].tolist(), 'label': train_df['label'].tolist()},
        'test': {'text': test_df['text'].tolist(), 'label': test_df['label'].tolist()}
    }